import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; 
import 'package:tugasmobile/components/coffee_tile.dart'; 
import 'package:tugasmobile/models/coffee.dart'; 
import 'package:tugasmobile/models/coffee_shop.dart'; 
import 'package:tugasmobile/pages/detail_page.dart'; 
import 'package:intl/intl.dart'; 

class ShopPage extends StatefulWidget {
  const ShopPage({super.key});

  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  // Fungsi untuk menambahkan kopi ke keranjang favorit
  void addToCart(Coffee coffee) {
    final coffeeShop = Provider.of<CoffeeShop>(context, listen: false);

    // Cek apakah kopi sudah ada di keranjang favorit
    if (coffeeShop.userCart.contains(coffee)) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(
            "Kopi ini sudah ada di favorit Anda!",
            style: TextStyle(fontSize: 18),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("OK"),
            ),
          ],
        ),
      );
    } else {
      // Tambahkan kopi ke keranjang
      coffeeShop.addItemToCart(coffee);

      // Pemberitahuan kopi berhasil ditambahkan
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(
            "Berhasil ditambahkan ke favorit!",
            style: TextStyle(fontSize: 18),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(), 
              child: Text("OK"),
            ),
          ],
        ),
      );
    }
  }

  // Fungsi untuk menavigasi ke halaman detail kopi
  void navigateToDetailPage(Coffee coffee) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailPage(coffee: coffee), 
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // fungsi datetime
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('yyyy-MM-dd – kk:mm').format(now);

    // mengatur tata letak halaman
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255), 
      appBar: AppBar(
        title: Text(
          'KopiKita',
          style: TextStyle(
            color: const Color.fromARGB(255, 254, 251, 250),
          ),
        ),
        backgroundColor: Colors.brown,
      ),
      body: Consumer<CoffeeShop>(
        builder: (context, value, child) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(25.0), 
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, 
              children: [
                // Menampilkan datetime
                Text(
                  'Tanggal dan Waktu: $formattedDate',
                  style: TextStyle(
                    fontSize: 18,
                    color: const Color.fromARGB(255, 29, 28, 28), 
                  ),
                ),
                const SizedBox(height: 25),

                // halaman utama
                Center(
                  child: const Text(
                    "Daftar Kopi",
                    style: TextStyle(
                      fontSize: 30, 
                      fontWeight: FontWeight.bold,
                      color: Colors.brown, 
                      letterSpacing: 2, 
                      shadows: [
                        Shadow(
                          blurRadius: 10.0, 
                          color: Color.fromARGB(115, 232, 153, 103), 
                          offset: Offset(2, 2), 
                        ),
                      ],
                      fontFamily: 'Dancing Script',
                    ),
                  ),
                ),
                const SizedBox(height: 25),

                // Daftar kopi 
                Expanded(
                  child: ListView.builder(
                    itemCount: value.coffeeShop.length,
                    itemBuilder: (context, index) {
                      Coffee eachCoffee = value.coffeeShop[index];

                      // Penggunaan card 
                      return GestureDetector(
                        onTap: () => navigateToDetailPage(eachCoffee),
                        child: Card(
                          margin: const EdgeInsets.only(bottom: 15), 
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15), 
                          ),
                          child: CoffeeTile(
                            coffee: eachCoffee,
                            icon: Icon(Icons.add), 
                            onPressed: () => addToCart(eachCoffee), 
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
