import 'package:flutter/material.dart';
import 'coffee.dart';

class CoffeeShop extends ChangeNotifier {
  // Daftar kopi yang tersedia
  final List<Coffee> _shop = [
    Coffee(name: 'Long Black', price: "Rp 25.000", imagePath: "lib/images/longblack.png"),
    Coffee(name: 'Latte', price: "Rp 28.000", imagePath: "lib/images/latte.png"),
    Coffee(name: 'Espresso', price: "Rp 22.000", imagePath: "lib/images/espresso.png"),
    Coffee(name: 'Americano', price: "Rp 30.000", imagePath: "lib/images/americano.png"),
  ];

  // Keranjang favorit pengguna
  List<Coffee> _userCart = [];

  // daftar kopi yang tersedia
  List<Coffee> get coffeeShop => _shop;
  
  // daftar kopi dalam keranjang favorit
  List<Coffee> get userCart => _userCart;

  // Menambahkan kopi ke keranjang
  void addItemToCart(Coffee coffee) {
    // Memeriksa apakah kopi sudah ada di keranjang
    if (_userCart.contains(coffee)) {
      // Jika kopi sudah ada di keranjang, tidak melakukan apa-apa
      return;
    }
    // Jika tidak ada di keranjang, tambahkan kopi ke keranjang favorit
    _userCart.add(coffee);
    notifyListeners();
  }

  // Menghapus kopi dari keranjang
  void removeItemFromCart(Coffee coffee) {
    // Menghapus kopi dari keranjang jika ada
    _userCart.remove(coffee);
    // Memberitahukan pendengar (listeners) bahwa ada perubahan
    notifyListeners();
  }
}
