import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; 
import 'package:tugasmobile/models/coffee_shop.dart'; 
import 'package:tugasmobile/pages/home_page.dart'; 

// Fungsi utama (main) yang menjalankan aplikasi
void main() {
  runApp(const MyApp()); 
}

// Widget MyApp merupakan root dari aplikasi
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  @override
  // mengakses ke objek coffeeshop
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => CoffeeShop(),
      builder: (context, child) => const MaterialApp(
        debugShowCheckedModeBanner: false, 
        home: HomePage(),
      ),
    );
  }
}
