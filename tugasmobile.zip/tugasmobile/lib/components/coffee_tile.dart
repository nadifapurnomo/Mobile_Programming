import 'package:flutter/material.dart';
import 'package:tugasmobile/models/coffee.dart';

class CoffeeTile extends StatelessWidget {
  // Objek kopi yang akan ditampilkan di tile
  final Coffee coffee;
  
  // Ikon yang akan ditampilkan di trailing
  final Icon icon;
  
  // Callback yang akan dipanggil saat ikon ditekan
  final VoidCallback onPressed;

  CoffeeTile({
    required this.coffee,
    required this.icon,
    required this.onPressed,
  });

  @override
  // Mengatur tata letak informasi kopi
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.all(8.0), 
      leading: Image.asset(coffee.imagePath), 
      title: Text(coffee.name), 
      subtitle: Text('${coffee.price}'),
      trailing: IconButton(
        icon: icon, 
        onPressed: onPressed, 
      ),
    );
  }
}
