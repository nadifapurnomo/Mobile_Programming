import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class MyBottomNavBar extends StatelessWidget {
  // Callback tab berubah
  final void Function(int)? onTabChange;

  // Konstruktor dengan parameter onTabChange
  MyBottomNavBar({super.key, required this.onTabChange});

  @override
  Widget build(BuildContext context) {
    return Container(
      // Kontainer utama dengan dekorasi
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 255, 255, 255),
      ),
      child: Container(
        margin: const EdgeInsets.all(15.0), 
        padding: const EdgeInsets.symmetric(vertical: 8.0), 
        decoration: BoxDecoration(
          color: Colors.brown,
          borderRadius: BorderRadius.circular(30), 
        ),
        child: GNav(
          onTabChange: (value) => onTabChange!(value), 
          color: const Color.fromRGBO(255, 255, 255, 1),
          backgroundColor: Colors.transparent, 
          mainAxisAlignment: MainAxisAlignment.spaceEvenly, 
          activeColor: Colors.white, 
          tabBackgroundColor: Colors.brown.shade700,
          tabBorderRadius: 30, 
          tabActiveBorder: Border.all(color: Colors.brown.shade800, width: 2), 
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 16), 
          tabs: const [
            // Daftar tab dengan ikon dan teks
            GButton(
              icon: Icons.home,
              text: 'Home', 
              iconSize: 24, 
            ),
            GButton(
              icon: Icons.favorite, 
              text: 'Favorite', 
              iconSize: 24, 
            ),
            GButton(
              icon: Icons.account_circle, 
              text: 'Profile', 
              iconSize: 24, 
            ),
          ],
        ),
      ),
    );
  }
}
