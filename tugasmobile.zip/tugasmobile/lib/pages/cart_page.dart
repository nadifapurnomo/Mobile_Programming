import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tugasmobile/components/coffee_tile.dart'; 
import 'package:tugasmobile/models/coffee.dart'; 
import 'package:tugasmobile/models/coffee_shop.dart'; 

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // Fungsi untuk menghapus item dari keranjang
  void removeFromCart(Coffee coffee) {
    Provider.of<CoffeeShop>(context, listen: false).removeItemFromCart(coffee);

    // Pemberitahuan Snackbar setelah item dihapus
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${coffee.name} telah dihapus dari favorit Anda.'),
        duration: Duration(seconds: 2), 
      ),
    );
  }

  @override
  // Mengatur tampilan halaman
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, 
      appBar: AppBar(
        title: Text(
          'KopiKita',
          style: TextStyle(
            color: const Color.fromARGB(255, 254, 251, 250), 
          ),
        ),
        backgroundColor: Colors.brown, 
      ),
      body: Consumer<CoffeeShop>(
        builder: (context, value, child) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(25.0),
            child: Column(
              children: [
                Center(
                  child: const Text(
                    "Favorit Anda",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.brown, 
                      letterSpacing: 2, 
                      shadows: [
                        Shadow(
                          blurRadius: 10.0, 
                          color: Color.fromARGB(115, 232, 153, 103), 
                          offset: Offset(2, 2),
                        ),
                      ],
                      fontFamily: 'Dancing Script', 
                    ),
                  ),
                ),
                const SizedBox(height: 25),

                // Daftar item di keranjang favorit
                Flexible(
                  child: ListView.builder(
                    itemCount: value.userCart.length, 
                    itemBuilder: (context, index) {
                      Coffee eachCoffee = value.userCart[index];

                      // Card yang berisi CoffeeTile
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10), 
                        elevation: 5, 
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15), 
                        ),
                        child: CoffeeTile(
                          coffee: eachCoffee,
                          onPressed: () => removeFromCart(eachCoffee),
                          icon: Icon(Icons.delete), 
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
