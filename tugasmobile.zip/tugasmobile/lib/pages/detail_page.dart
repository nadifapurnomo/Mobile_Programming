import 'package:flutter/material.dart';
import 'package:tugasmobile/models/coffee.dart';
class DetailPage extends StatelessWidget {
  final Coffee coffee; 

  const DetailPage({super.key, required this.coffee}); 

  @override
  Widget build(BuildContext context) {
    // Mengatur tampilan halaman detail page
    return Scaffold(
      appBar: AppBar(
        title: Text(coffee.name), 
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), 
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(coffee.imagePath), 
            SizedBox(height: 16),
            Text(
              coffee.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              coffee.price,
              style: TextStyle(fontSize: 20, color: Colors.grey[600]),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
