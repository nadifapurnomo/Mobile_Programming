import 'package:flutter/material.dart';
import 'package:tugasmobile/components/bottom_nav_bar.dart';
import 'package:tugasmobile/pages/profile_page.dart';
import 'cart_page.dart';
import 'shop_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Menyimpan indeks halaman yang dipilih
  int _selectedIndex = 0;

  // Fungsi untuk menampilkan halaman yg dipilih
  void navigateBottomBar(int index) {
    setState(() {
      _selectedIndex = index; 
    });
  }

  // Daftar halaman yang tersedia di aplikasi
  final List<Widget> _pages = [
    // Halaman toko
    ShopPage(),

    // Halaman favorite
    CartPage(),

    // Halaman profil
    ProfilePage()
  ];

  @override
  // Mengatur peralihan halaman
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, 
      bottomNavigationBar: MyBottomNavBar(
        onTabChange: (index) => navigateBottomBar(index),
      ),
      body: _pages[_selectedIndex], 
    );
  }
}
